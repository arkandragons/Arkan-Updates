local l = (data.bl and 1) or -1
local player = data.player
local item = data.item
local mainHand = data.mainHand

local climbing    = P:isClimbing(player)
local swimming    = P:isSwimming(player)
local crawling    = P:isCrawling(player)
local interacting = interact
local breaking    = blockBreaking

local active = climbing or swimming or crawling or interacting or breaking

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;
global.GHP_disableShearing = 0.0;
global.GHP_isActive = 0.0;
global.GHP_prevIsActive = 0.0;
global.GHP_customShearsMPA = 0;
global.GHP_leftShearsStart = 0;
global.GHP_leftShearsEnd = 29;
global.GHP_rightShearsStart = 30;
global.GHP_rightShearsEnd = 59;
global.GHP_leftShearsRot = 12.5;
global.GHP_rightShearsRot = -12.5;
local isHandPosesActive = (GHP_prevIsActive ~= GHP_isActive)

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local totem = {
    "minecraft:totem_of_undying"
}
local shears = {
    "minecraft:shears"
}
local bows = {
    "minecraft:bow"
}
local bowss = {
    "minecraft:crossbow"
}
local flint = {
    "minecraft:flint_and_steel"
}
local brush = {
    "minecraft:brush"
}
local tri = {
    "minecraft:trident"
}
local heavy = {
    "minecraft:netherite_axe",
    "minecraft:diamond_axe",
    "minecraft:golden_axe",
    "minecraft:iron_axe",
    "minecraft:copper_axe",
    "minecraft:stone_axe",
    "minecraft:wooden_axe",
    "minecraft:copper_axe",

    "minecraft:netherite_pickaxe",
    "minecraft:diamond_pickaxe",
    "minecraft:golden_pickaxe",
    "minecraft:iron_pickaxe",
    "minecraft:copper_pickaxe",
    "minecraft:stone_pickaxe",
    "minecraft:wooden_pickaxe",
    "minecraft:copper_pickaxe",

    "minecraft:mace",
}

local shovels = {
    "minecraft:netherite_shovel",
    "minecraft:diamond_shovel",
    "minecraft:golden_shovel",
    "minecraft:iron_shovel",
    "minecraft:stone_shovel",
    "minecraft:wooden_shovel",
    "minecraft:copper_shovel"
}

local swords = {
    "minecraft:netherite_sword",
    "minecraft:diamond_sword",
    "minecraft:golden_sword",
    "minecraft:iron_sword",
    "minecraft:copper_sword",
    "minecraft:stone_sword",
    "minecraft:wooden_sword",
    "minecraft:copper_sword"
}

local hoes = {
    "minecraft:netherite_hoe",
    "minecraft:diamond_hoe",
    "minecraft:golden_hoe",
    "minecraft:iron_hoe",
    "minecraft:copper_hoe",
    "minecraft:stone_hoe",
    "minecraft:wooden_hoe",
    "minecraft:copper_hoe"
}

local fishing_rods = {
    "minecraft:fishing_rod"
}

local carrot = {
    "minecraft:carrot_on_a_stick"
}

local fungus = {
    "minecraft:warped_fungus_on_a_stick"
}

local function isIn(list)
    for _, id in ipairs(list) do
        if I:isOf(item, Items:get(id)) then return true end
    end
    return false
end

if I:isOf(data.item, Items:get("minecraft:fishing_rod")) then
    animator:rotateZ( 0, 25, -ywAngle, 0.5, 1.8, 0.5)
    animator:rotateX( 0, 25, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(0, 25, 0.05)
end

if I:isOf(data.item, Items:get("minecraft:carrot_on_a_stick")) then
    animator:rotateZ( 0, 33, -ywAngle, 0.5, 1.8, 0.5)
    animator:rotateX( 0, 33, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(0, 33, 0.05)
        return
end

if I:isOf(data.item, Items:get("minecraft:warped_fungus_on_a_stick")) then
    animator:rotateZ( 0, 13, -ywAngle, 0.5, 1.8, 0.5)
    animator:rotateX( 0, 13, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(0, 13, 0.05)
        return
end



GHP_customShearsMPA = GHP_customShearsMPA + 1
GHP_leftShearsStart = 0
GHP_leftShearsEnd = 29
GHP_rightShearsStart = 30
GHP_rightShearsEnd = 59
GHP_leftShearsRot = 12.5;
GHP_rightShearsRot = -12.5;

GHP_prevIsActive = GHP_isActive

