global.offhand = 0;

local l = (context.bl and 1) or -1
local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand

local smooth      = registry:getOrDefault("smoothCrossbow", 0.0)
local hadCrossbow = registry:getOrDefault("hadCrossbowPose", false)
local delay       = registry:getOrDefault("crossbowOffhandDelay", 1.0)
local wasEquipped = registry:getOrDefault("crossbowWasEquipped", false)
local exit        = registry:getOrDefault("crossbowExitPose", false)

local isCharged   = I:isChargedCrossbow(P:getMainItem(player))
local isShield = I:isOf(P:getOffhandItem(player), Items:get("minecraft:shield"))
local isLantern = I:isOf(P:getOffhandItem(player), Items:get("minecraft:lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:soul_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:exposed_copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:weathered_copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:oxidized_copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:waxed_copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:waxed_exposed_copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:waxed_weathered_copper_lantern"))
              or I:isOf(P:getOffhandItem(player), Items:get("minecraft:waxed_oxidized_copper_lantern"))
                            

local enxadas = I:isOf(item, Items:get("minecraft:mace"))
              or I:isOf(item, Items:get("minecraft:wooden_hoe"))
              or I:isOf(item, Items:get("minecraft:stone_hoe"))
              or I:isOf(item, Items:get("minecraft:copper_hoe"))
              or I:isOf(item, Items:get("minecraft:iron_hoe"))
              or I:isOf(item, Items:get("minecraft:diamond_hoe"))
              or I:isOf(item, Items:get("minecraft:golden_hoe"))
              or I:isOf(item, Items:get("minecraft:netherite_hoe"))
              or I:isOf(item, Items:get("minecraft:diamond_axe"))
              or I:isOf(item, Items:get("minecraft:golden_axe"))
              or I:isOf(item, Items:get("minecraft:copper_axe"))
              or I:isOf(item, Items:get("minecraft:iron_axe"))
              or I:isOf(item, Items:get("minecraft:stone_axe"))
              or I:isOf(item, Items:get("minecraft:wooden_axe"))
              or I:isOf(item, Items:get("minecraft:netherite_axe"))
              or I:isOf(item, Items:get("minecraft:diamond_pickaxe"))
              or I:isOf(item, Items:get("minecraft:netherite_pickaxe"))
              or I:isOf(item, Items:get("minecraft:golden_pickaxe"))
              or I:isOf(item, Items:get("minecraft:iron_pickaxe"))
              or I:isOf(item, Items:get("minecraft:copper_pickaxe"))
              or I:isOf(item, Items:get("minecraft:stone_pickaxe"))
              or I:isOf(item, Items:get("minecraft:wooden_pickaxe"))
              or I:isOf(item, Items:get("minecraft:iron_shovel"))
              or I:isOf(item, Items:get("minecraft:diamond_shovel"))
              or I:isOf(item, Items:get("minecraft:golden_shovel"))
              or I:isOf(item, Items:get("minecraft:copper_shovel"))
              or I:isOf(item, Items:get("minecraft:netherite_shovel"))
              or I:isOf(item, Items:get("minecraft:wooden_shovel"))
              or I:isOf(item, Items:get("minecraft:stone_shovel"))
              or I:isOf(item, Items:get("minecraft:golden_sword"))
              or I:isOf(item, Items:get("minecraft:copper_sword"))
              or I:isOf(item, Items:get("minecraft:diamond_sword"))
              or I:isOf(item, Items:get("minecraft:iron_sword"))
              or I:isOf(item, Items:get("minecraft:netherite_sword"))
              or I:isOf(item, Items:get("minecraft:wooden_sword"))
              or I:isOf(item, Items:get("minecraft:stone_sword"))
            
local blocking = P:isSwimming(player)
               or P:isCrawling(player)
               or P:isClimbing(player)
local speed = 1.5 
local swingOffset = math.sin(math.min(context.mainHandSwingProgress * math.pi * speed, math.pi)) * 0.5

global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

if I:isOf(item, Items:get("minecraft:name_tag")) then
    M:moveY(matrices, 0.25)
    M:moveZ(matrices, -0.05)
end

if not wasEquipped and isCharged then
    delay = 0
elseif delay < 1 then
    delay = math.min(delay + 0.02, 1)
end

if blocking then
    exit = true
end

if exit then
    smooth = math.max(smooth - 0.08, 0)
    if smooth == 0 then
        exit = false
        hadCrossbow = false
    end
elseif delay >= 1 then
    if isCharged then
        hadCrossbow = true
        smooth = math.min(smooth + 0.05, 1)
    elseif hadCrossbow then
        smooth = math.max(smooth - 0.05, 0)
        if smooth == 0 then
            hadCrossbow = false
        end
    else
        smooth = 0
    end
else
    smooth = 0
end

registry:put("smoothCrossbow", smooth)
registry:put("hadCrossbowPose", hadCrossbow)
registry:put("crossbowOffhandDelay", delay)
registry:put("crossbowWasEquipped", isCharged)
registry:put("crossbowExitPose", exit)

if I:isOf(item, Items:get("minecraft:crossbow")) and P:isUsingItem(player) and not isCharged and mainHand then
    M:moveX(matrices, -0.2)
    M:moveZ(matrices, -0.2)
    M:rotateY(matrices, -20)
    return
end

if smooth > 0 then

    if not I:isEmpty(P:getOffhandItem(player)) and not mainHand then

        local offhandSwingX = -swingOffset * 0.5
        local offhandSwingZ = -swingOffset * 0.3
        local offhandSwingRot = swingOffset * 25

        if isShield then
            M:moveX(matrices, (-0.85 * smooth) + offhandSwingX)
            M:moveY(matrices, -0.05 * smooth)
            M:moveZ(matrices, (-0.6 * smooth) - offhandSwingZ)
            M:rotateX(matrices, 30 * smooth)
            M:rotateY(matrices, (-50 * smooth) + offhandSwingRot)
            M:rotateZ(matrices, 70 * smooth )
            return
        end
        
        if isLantern then
            M:moveX(matrices, (-0.72 * smooth) + offhandSwingX)
            M:moveY(matrices, (-0.35 * smooth))
            M:moveZ(matrices, (-0.5 * smooth) - offhandSwingZ)
            M:rotateX(matrices, (30 * smooth))
            M:rotateY(matrices, (-60 * smooth) + offhandSwingRot)
            M:rotateZ(matrices, (80 * smooth))
            return
        end
        
        M:moveX(matrices, (-0.7 * smooth) + offhandSwingX)
        M:moveY(matrices, -0.04 * smooth)
        M:moveZ(matrices, (-0.5 * smooth) - offhandSwingZ)
        M:rotateX(matrices, 30 * smooth)
        M:rotateY(matrices, (-50 * smooth) + offhandSwingRot)
        M:rotateZ(matrices, 70 * smooth)
        return
    end

    if delay == 1 and isCharged and I:isEmpty(P:getOffhandItem(player)) then
        offhand = -0.1
    end

    if mainHand then
        M:moveX(matrices, -0.35 * smooth)
        M:moveZ(matrices, (-0.40 * smooth) + (swingOffset * 0.2))
    else

        local emptySwingX = -swingOffset * 0.4
        M:moveX(matrices, (-0.80 * smooth) + emptySwingX)
        M:moveZ(matrices, -0.30 * smooth)
        M:moveY(matrices, (0.10 * smooth) + (swingOffset * 0.2))
        M:rotateY(matrices, (-80 * smooth) + (swingOffset * 30))
        M:rotateZ(matrices, 10 * smooth)
    end
end
if  I:isOf(P:getMainItem(player), Items:get("minecraft:fishing_rod")) then
    if mainHand then
    M:rotateX(matrices, -30)
    M:rotateY(matrices, -10)
    M:moveY(matrices, 0.4)
    M:moveX(matrices, -0.2)
    M:moveZ(matrices, -0.2)
    return
    end
end



if I:isOf(P:getMainItem(player), Items:get("minecraft:warped_fungus_on_a_stick")) or I:isOf(P:getMainItem(player), Items:get("minecraft:carrot_on_a_stick")) then
    if  mainHand then
    M:rotateX(matrices, -30)
    M:rotateY(matrices, -10)
    M:moveY(matrices, 0.4)
    M:moveX(matrices, -0.2)
    M:moveZ(matrices, -0.2)
    return
    end
end

if  I:isOf(P:getOffhandItem(player), Items:get("minecraft:fishing_rod")) then
    if not mainHand then
    M:rotateX(matrices, -30)
    M:rotateY(matrices, -10)
    M:moveY(matrices, 0.4)
    M:moveX(matrices, -0.2)
    M:moveZ(matrices, -0.2)
    return
    end
end

if I:isOf(P:getOffhandItem(player), Items:get("minecraft:warped_fungus_on_a_stick")) or I:isOf(P:getOffhandItem(player), Items:get("minecraft:carrot_on_a_stick")) then
    if  not mainHand then
    M:rotateX(matrices, -30)
    M:rotateY(matrices, -10)
    M:moveY(matrices, 0.4)
    M:moveX(matrices, -0.2)
    M:moveZ(matrices, -0.2)
    return
    end
end

if enxadas then
    M:rotateX(matrices, 10)
    M:moveY(matrices, -0.1)
    M:moveX(matrices, 0.0)
    M:moveZ(matrices, 0.06)
    return
end
