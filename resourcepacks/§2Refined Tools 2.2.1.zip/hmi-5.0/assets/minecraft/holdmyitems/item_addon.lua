local l = (bl and 1) or -1
local lb =(bl and 0.8) or -0.2

local climbing    = P:isClimbing(player)
local swimming    = P:isSwimming(player)
local crawling    = P:isCrawling(player)
local interacting = interact
local breaking    = blockBreaking

local active = climbing or swimming or crawling or interacting or breaking

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;
global.GHP_isActive = 0.0;
global.GHP_prevIsActive = 0.0;
global.GHP_customShearsMPA = 0;
global.GHP_leftShearsStart = 0;
global.GHP_leftShearsEnd = 29;
global.GHP_rightShearsStart = 30;
global.GHP_rightShearsEnd = 59;
global.GHP_leftShearsRot = 12.5;
global.GHP_rightShearsRot = -12.5;
local isHandPosesActive = (GHP_prevIsActive ~= GHP_isActive)

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

if I:isOf(item, Items:get("minecraft:name_tag")) then
    M:moveY(matrices, -0.2)
    M:moveX(matrices, -0.05 * l)
    M:rotateX(matrices, -70)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle + ywAngle * 0.5, 0, -0.13, 0)
  M:rotateZ(matrices, ywAngle * -0.3, -0.1 * l, 0, 0.1)

end
local totem = {
    "minecraft:totem_of_undying"
}
local shears = {
    "minecraft:shears"
}
local bows = {
    "minecraft:bow"
}
local bowss = {
    "minecraft:crossbow"
}
local flint = {
    "minecraft:flint_and_steel"
}
local brush = {
    "minecraft:brush"
}
local tri = {
    "minecraft:trident"
}
local heavy = {
    "minecraft:netherite_axe",
    "minecraft:diamond_axe",
    "minecraft:golden_axe",
    "minecraft:iron_axe",
    "minecraft:copper_axe",
    "minecraft:stone_axe",
    "minecraft:wooden_axe",
    "minecraft:copper_axe",

    "minecraft:netherite_pickaxe",
    "minecraft:diamond_pickaxe",
    "minecraft:golden_pickaxe",
    "minecraft:iron_pickaxe",
    "minecraft:copper_pickaxe",
    "minecraft:stone_pickaxe",
    "minecraft:wooden_pickaxe",
    "minecraft:copper_pickaxe",

    "minecraft:mace",
}

local shovels = {
    "minecraft:netherite_shovel",
    "minecraft:diamond_shovel",
    "minecraft:golden_shovel",
    "minecraft:iron_shovel",
    "minecraft:stone_shovel",
    "minecraft:wooden_shovel",
    "minecraft:copper_shovel"
}

local swords = {
    "minecraft:netherite_sword",
    "minecraft:diamond_sword",
    "minecraft:golden_sword",
    "minecraft:iron_sword",
    "minecraft:copper_sword",
    "minecraft:stone_sword",
    "minecraft:wooden_sword",
    "minecraft:copper_sword"
}

local hoes = {
    "minecraft:netherite_hoe",
    "minecraft:diamond_hoe",
    "minecraft:golden_hoe",
    "minecraft:iron_hoe",
    "minecraft:copper_hoe",
    "minecraft:stone_hoe",
    "minecraft:wooden_hoe",
    "minecraft:copper_hoe"
}

local fishing_rods = {
    "minecraft:fishing_rod"
}

local carrotfungus = {
    "minecraft:carrot_on_a_stick",
    "minecraft:warped_fungus_on_a_stick"
}


local function isIn(list)
    for _, id in ipairs(list) do
        if I:isOf(item, Items:get(id)) then return true end
    end
    return false
end

if isIn(brush) then
        M:scale(matrices, 0.85, 0.85, 0.85)
        M:moveY(matrices, 0.1)

   
end

if isIn(bows) then
    if mainHand then
        M:moveX(matrices, 0.05)
        M:moveY(matrices, 0.02)
    else
        M:moveX(matrices, -0.05)
        M:moveY(matrices, 0.02)
    end
end
if isIn(bowss) and not I:isChargedCrossbow(P:getMainItem(player)) and not P:isUsingItem(player) then
    M:moveZ(matrices, -0.05)
end

local main = P:getMainItem(player)

if I:isOf(main, Items:get("minecraft:crossbow")) then
    local off = P:getOffhandItem(player)

    if I:isChargedCrossbow(main) and item == off and not I:isEmpty(off) and not active then
        if not (I:isOf(item, Items:get("minecraft:air"))) then
            M:scale(matrices, 0, 0, 0)
            
            return
        end
    end

    if I:isChargedCrossbow(main) then
        if mainHand then
            M:moveX(matrices, -0.05)
            M:rotateY(matrices, -5)
            M:rotateZ(matrices, 5)
            M:moveZ(matrices, 0.2)
            M:moveY(matrices, 0.05)
        else
            M:moveX(matrices, -0.05)
        end
    end
end


if isIn(heavy) then
    M:scale(matrices, 0.85, 0.85, 0.85)
    M:moveY(matrices, 0.05)
    M:rotateX(matrices, -10)
end

if isIn(shovels) then
    if item == P:getOffhandItem(player) then
        M:scale(matrices, 0.85, 0.85, 0.85)
        M:moveZ(matrices, 0.15)
        M:moveX(matrices, -0.05)
        M:moveY(matrices, -0.2)
        M:rotateX(matrices, -5)
        M:rotateZ(matrices, 10)
        M:rotateY(matrices, 90)
    else
        M:scale(matrices, 0.85, 0.85, 0.85)
        M:moveZ(matrices, 0.15)
        M:moveX(matrices, 0.05)
        M:moveY(matrices, -0.2)
        M:rotateX(matrices, -5)
        M:rotateZ(matrices, -10)
        M:rotateY(matrices, -90)
       
    end
end

if isIn(swords) then
    M:scale(matrices, 0.85, 0.85, 0.85)
    M:rotateX(matrices, -10)
end

if isIn(tri) then
    M:scale(matrices, 0.85, 0.85, 0.85)
    M:moveX(matrices, -0.1)
    M:moveZ(matrices, 0.02)
end

if isIn(hoes) then
    M:scale(matrices, 0.85, 0.85, 0.85)
end

if isIn(fishing_rods) then
        M:scale(matrices, 0.85, 0.85, 0.85)
        M:rotateX(matrices, -20)
        M:moveX(matrices, 0.05 * l)
end

if isIn(carrotfungus) then
    M:scale(matrices, 0.85, 0.85, 0.85)
    M:rotateX(matrices, -20)
    M:moveX(matrices, 0.1 * l)
    M:rotateY(matrices, 10 * l)
    M:moveY(matrices, -0.02)
end

if isIn(flint) then
    M:scale(matrices, 1.2, 1.2, 1.2)
    M:moveZ(matrices, -0.05)
end

if isIn(shears) and not isHandPosesActive then
    M:rotateZ(matrices, -40 )
    M:moveX(matrices, 0.05 * l)
    M:moveY(matrices, 0.05 )
    return
end 
if isIn(shears) and isHandPosesActive then
    M:moveX(matrices, -0.01)
    M:moveZ(matrices, 0.1)
    M:moveY(matrices, 0.01)
end


GHP_customShearsMPA = GHP_customShearsMPA + 1
GHP_leftShearsStart = 0
GHP_leftShearsEnd = 29
GHP_rightShearsStart = 30
GHP_rightShearsEnd = 59
GHP_leftShearsRot = 12.5;
GHP_rightShearsRot = -12.5;

if isIn(totem) then
    M:scale(matrices, 1.1, 1.1, 1.1)
    M:moveY(matrices, -0.05)
    M:moveX(matrices, 0.05 * l)
    M:moveZ(matrices, -0.08) 
    M:rotateX(matrices, -20)
    M:rotateY(matrices, 10 * l)
particleManager:addParticle(
particles,
false,
-0.05 * l,
0.05,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
2.5,
Texture:of("minecraft", "textures/particle/laranja.png"),
"ITEM",
hand,
"SPAWN",
"ADDITIVE",
0,
150 + (20 * M:sin(P:getAge(player) * 0.2))
)
end

