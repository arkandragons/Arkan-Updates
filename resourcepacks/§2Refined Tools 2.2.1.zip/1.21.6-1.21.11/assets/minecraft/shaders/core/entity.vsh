#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float vSphericalDist;
out float vCylindricalDist;
out vec4 vColor;
out vec4 vOverlay;
out vec2 vTex0;

// patovskiz was here
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vSphericalDist = fog_spherical_distance(Position);
    vCylindricalDist = fog_cylindrical_distance(Position);

    vColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    vOverlay = texelFetch(Sampler1, UV1, 0);
    vTex0 = UV0;
}