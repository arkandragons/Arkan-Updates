#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float vSphericalDist;
in float vCylindricalDist;
in vec4 vColor;
in vec2 vTex0;

out vec4 fragColor;

vec4 apply_env_fog(vec4 color, float sDist, float cDist) {
    float f = clamp(max(smoothstep(FogEnvironmentalStart, FogEnvironmentalEnd, sDist), 
                        smoothstep(FogRenderDistanceStart, FogRenderDistanceEnd, cDist)), 0.0, 1.0);
    return vec4(mix(color.rgb, FogColor.rgb, f * FogColor.a), color.a);
}

// patovskiz was here
void main() {
    vec4 tex = texture(Sampler0, vTex0);
    vec4 lit = tex * vColor * ColorModulator;

    if (lit.a < 0.1) discard;

    int a = int(round(lit.a * 255.0));

    if (a >= 250 && a <= 254) {
        float m = (a == 251) ? 0.75 : (a == 250 ? 0.5 : 1.0);
        vec4 res = tex * ColorModulator;
        res.rgb *= m;
        res.a = lit.a;
        fragColor = res;
        return;
    }

    fragColor = apply_env_fog(lit, vSphericalDist, vCylindricalDist);
}