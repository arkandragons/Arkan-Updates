function easeOutBack(t, back, speed)
    back = back or 1.70158
    speed = speed or 1.0
    t = math.min(math.max(t * speed, 0), 1)
    t = t - 1
    return (t * t * ((back + 1) * t + back) + 1)
end

function easeCustom(t)
    local t2 = t * t
    local t3 = t2 * t
    return 3 * t * (1 - t) * (1 - t) * 0.44 +
            3 * t2 * (1 - t) * 1 +
            t3
end

function easeCustomSec(t)
	local t2 = t * t
	local t3 = t2 * t
	return 3 * t * (1 - t) * (1 - t) * 0.44 +
		3 * t2 * (1 - t) * 0.94 +
		t3
end

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

global.GHP_disableShearing = 0.0;
global.GHP_disableShearingMPA = 0.0;

GHP_disableShearing = GHP_disableShearing + 1	-- disable shearing
GHP_disableShearingMPA = GHP_disableShearingMPA + 1	-- disable shears modelpart animation

local ptAngle = context.ptAngle or 0
local ywAngle = context.ywAngle or 0

local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO

local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local particles = context.particles
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent

local ptAngle = context.ptAngle or 0
local ywAngle = context.ywAngle or 0

local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO
         
local hand = context.hand  
local onRedstone = P:getStandingBlock(context.player) == "minecraft:redstone_block"
local age = P:getAge(context.player)
local crackleTick = M:floor(age/3)
local redstoneParticles = {
    "textures/particle/redstone_dust/redstone_dust_0.png",
    "textures/particle/redstone_dust/redstone_dust_1.png",
    "textures/particle/redstone_dust/redstone_dust_2.png",
    "textures/particle/redstone_dust/redstone_dust_3.png",
    "textures/particle/redstone_dust/redstone_dust_4.png"
}  

local l = (bl and 1) or -1

local function noBlocksPlease(blocks)
    for _, id in ipairs(blocks) do
        renderAsBlock:put(id, false)
    end
end

noBlocksPlease({
    "minecraft:firefly_bush",
    "minecraft:wither_rose",
    "minecraft:open_eyeblossom",
    "minecraft:closed_eyeblossom",
    "minecraft:cactus_flower",
    "minecraft:torchflower",
    "minecraft:lily_of_the_valley",
    "minecraft:cornflower",
    "minecraft:oxeye_daisy",
    "minecraft:white_tulip",
    "minecraft:pink_tulip",
    "minecraft:red_tulip",
    "minecraft:orange_tulip",
    "minecraft:azure_bluet",
    "minecraft:allium",
    "minecraft:blue_orchid",
    "minecraft:poppy",
    "minecraft:dandelion",
    "minecraft:dead_bush",
    "minecraft:bush",
    "minecraft:short_dry_grass",
    "minecraft:tall_dry_grass",
    "minecraft:crimson_fungus",
    "minecraft:warped_fungus",
    "minecraft:short_grass",
    "minecraft:tall_grass",
    "minecraft:sugar_cane",
    "minecraft:fern",
    "minecraft:large_fern",
	"minecraft:pale_hanging_moss",
	"minecraft:hanging_roots",
    "minecraft:cherry_sapling",
    "minecraft:oak_sapling",
    "minecraft:spruce_sapling",
    "minecraft:birch_sapling",
    "minecraft:acacia_sapling",
    "minecraft:dark_oak_sapling",
    "minecraft:pale_oak_sapling",
    "minecraft:jungle_sapling",
    "minecraft:mangrove_propagule",
    "minecraft:pitcher_plant",
    "minecraft:peony",
    "minecraft:rose_bush",
    "minecraft:lilac",
    "minecraft:brown_mushroom",
    "minecraft:red_mushroom",
    "minecraft:crimson_roots",
    "minecraft:warped_roots",
    "minecraft:nether_sprouts",
    "minecraft:sunflower",
    "minecraft:bell",
})

if I:isOf(item, Items:get("minecraft:fishing_rod")) or I:isOf(item, Items:get("minecraft:warped_fungus_on_a_stick")) or I:isOf(item, Items:get("minecraft:carrot_on_a_stick")) then
	M:rotateX(matrices, -60)
	M:moveY(matrices, -0.2)
end

if I:isOf(item, Items:get("minecraft:totem_of_undying")) and mainHand then
	M:rotateX(matrices, -110)
	M:rotateZ(matrices, -190)
	M:rotateY(matrices, -10)
end

if I:isOf(item, Items:get("minecraft:totem_of_undying")) and not mainHand then
	M:rotateX(matrices, -110)
	M:rotateZ(matrices, -170)
	M:rotateY(matrices, 10)
end

if I:isOf(item, Items:get("minecraft:writable_book")) then
	M:rotateX(matrices, 25)
	M:moveY(matrices, 0.1)
end

if I:isOf(item, Items:get("minecraft:leaf_litter")) or I:isOf(item, Items:get("minecraft:pink_petals")) or I:isOf(item, Items:get("minecraft:wildflowers")) then
    M:rotateX(matrices, -5)
end

if I:isOf(item, Items:get("minecraft:glow_item_frame"))
or I:isOf(item, Items:get("minecraft:flower_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:creeper_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:skull_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:mojang_banner_pattern"))
or I:isOf(item, Items:get("minecraft:globe_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:snout_banner_pattern"))
or I:isOf(item, Items:get("minecraft:flow_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:guster_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:field_masoned_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:bordure_indented_banner_pattern")) 
or I:isOf(item, Items:get("minecraft:piglin_banner_pattern")) then
    M:moveY(matrices, -0.2)
    M:moveZ(matrices, 0.1)
    M:rotateX(matrices, -75)
end

if I:isOf(item, Items:get("minecraft:name_tag")) then
	M:moveY(matrices, -0.21)
    M:rotateX(matrices, -75)
	M:scale(matrices, 1.2, 1.2, 1.2)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 1, 0, 0) + ptAngle, 1, 0, -0.05, 0)
end

if I:isOf(item, Items:get("minecraft:flint_and_steel")) and mainHand then
    M:rotateX(matrices, -15)
    M:rotateY(matrices, -5)
	else if I:isOf(item, Items:get("minecraft:flint_and_steel")) then
    M:rotateX(matrices, -15)
    M:rotateY(matrices, 5)
	end
end

if I:isOf(item, Items:get("minecraft:painting")) and mainHand then
    M:moveY(matrices, 0.1)
    M:moveZ(matrices, 0.1)
    M:moveX(matrices, 0.1)
end

if I:isOf(item, Items:get("minecraft:painting")) and not mainHand then
    M:moveZ(matrices, 0.1)
    M:moveX(matrices, -0.1)
    M:moveY(matrices, 0.1)
end

if I:isOf(item, Items:get("minecraft:item_frame")) and mainHand then
    M:moveY(matrices, 0.1)
    M:moveZ(matrices, 0.1)
    M:moveX(matrices, 0.1)
end

if I:isOf(item, Items:get("minecraft:item_frame")) and not mainHand then
    M:moveZ(matrices, 0.1)
    M:moveX(matrices, -0.1)
    M:moveY(matrices, 0.1)
end

if I:isOf(item, Items:get("minecraft:glow_item_frame")) then
    M:rotateX(matrices, 70)
    M:moveY(matrices, -0.3)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 2, 0, 45) + ptAngle, 1, 0.4, -0.1, 0)
    M:rotateZ(matrices, M:clamp(P:getPitch(player) / 2, 0, 0) - ywAngle, 0, 0.4, -0.1, 0)
end


if I:isOf(item, Items:get("minecraft:flint_and_steel")) and mainHand then
    M:rotateX(matrices, -15)
    M:rotateY(matrices, -5)
	else if I:isOf(item, Items:get("minecraft:flint_and_steel")) then
    M:rotateX(matrices, -15)
    M:rotateY(matrices, 5)
	end
end

-- Create Section

if I:isOf(item, Items:get("create:super_glue")) and mainHand then
	M:moveY(matrices, 0.2)
	M:moveZ(matrices, 0.05)
	M:moveX(matrices, -0.05)
    M:rotateX(matrices, -90)
    M:rotateZ(matrices, -110)
	else if I:isOf(item, Items:get("create:super_glue")) then
	M:moveY(matrices, 0.2)
	M:moveZ(matrices, 0.08)
	M:moveX(matrices, -0.05)
    M:rotateX(matrices, -90)
    M:rotateZ(matrices, -85)
	end
end

 if I:isOf(item, Items:get("create:schematic_and_quill")) and mainHand then
    M:rotateZ(matrices, -15)
	M:moveY(matrices, 0.1)
	M:moveX(matrices, 0.1)
	else if I:isOf(item, Items:get("create:schematic_and_quill")) then
    M:rotateZ(matrices, -30)
	M:moveY(matrices, 0.2)
	M:moveX(matrices, -0.2)
	M:moveZ(matrices, 0.1)
	end
end


-- End of Create Section

if I:isOf(item, Items:get("minecraft:vine")) 
or I:isOf(item, Items:get("minecraft:twisting_vines")) 
or I:isOf(item, Items:get("minecraft:weeping_vines")) 
or I:isOf(item, Items:get("minecraft:pale_hanging_moss")) 
or I:isOf(item, Items:get("minecraft:hanging_roots"))  
or I:isOf(item, Items:get("minecraft:cave_vines")) then
    M:moveY(matrices, -0.2)
    M:moveZ(matrices, -0.03)
    M:rotateX(matrices, -75)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 1, -45, 90) + ptAngle + ywAngle * 1, 0, -0.05, 0)
end

if I:isOf(item, Items:get("minecraft:glow_lichen")) then
    M:rotateX(matrices, -75)
    M:moveZ(matrices, -0.03)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 1, -45, 90) + ptAngle + ywAngle * 1, 0, -0.05, 0)
end

if mainHand and I:isOf(item, Items:get("minecraft:glow_lichen")) then
   M:rotateZ(matrices, -30)
end

if not mainHand and I:isOf(item, Items:get("minecraft:glow_lichen")) then
   M:rotateZ(matrices, 30)
end

if I:isOf(item, Items:get("minecraft:shears")) and mainHand then
   M:rotateZ(matrices, -45)
   M:rotateX(matrices, -65)
   M:moveZ(matrices, -0.1)
end

if I:isOf(item, Items:get("minecraft:shears")) and not mainHand then
   M:rotateZ(matrices, -45)
   M:rotateX(matrices, 65)
   M:moveZ(matrices, 0.1)
   M:moveY(matrices, 0.1)
end

if I:isOf(item, Items:get("minecraft:shears")) and animator ~= nil then
    local strength = customMainSwing or customOffSwing or swingProgress or 0
    local eased = math.sin(strength * math.pi)
    local angle = 5 * eased
   
    local rx, ry, rz = 0, 0, 0
    local lx, ly, lz = 0.6, 0, 0
  
    animator:rotateZ(0, 14, angle, rx, ry, rz)
    animator:rotateZ(14, 28, -angle, lx, ly, lz)

    if s == nil then
        s = false
    end

    if strength > 0.4 and not s then
        S:playSound("item.shears.snip", 0.5)
        s = true
    end

    if strength < 0.4 then
        s = false
    end
end

if I:isOf(item, Items:get("minecraft:flint_and_steel")) then
   M:rotateX(matrices, 15)
end

-- glowing

if I:isOf(item, Items:get("minecraft:blaze_powder")) then   
    particleManager:addParticle(
        particles, false,
        0.1 * l, 0.15, 0,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        4,                           
        Texture:of("minecraft","textures/a3dsp/o_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:fire_charge")) then   
    particleManager:addParticle(
        particles, false,
        0.1 * l, 0, -0.1,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3,                           
        Texture:of("minecraft","textures/a3dsp/o_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:totem_of_undying")) then   
    particleManager:addParticle(
        particles, false,
        -0.1 * l, 0, 0.1,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3,                           
        Texture:of("minecraft","textures/a3dsp/o_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end	

if I:isOf(item, Items:get("minecraft:glowstone_dust")) then   
    particleManager:addParticle(
        particles, false,
        0.1 * l, -0.1, 0,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3.5,                           
        Texture:of("minecraft","textures/a3dsp/o_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
	
if I:isOf(item, Items:get("minecraft:enchanted_book")) then   
    particleManager:addParticle(
        particles, false,
        0 * l, 0, 0,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3.5,                           
        Texture:of("minecraft","textures/a3dsp/p_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:redstone")) then   
    particleManager:addParticle(
        particles, false,
        0.1 * l, -0.1, 0,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3.5,                           
        Texture:of("minecraft","textures/a3dsp/r_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:glow_ink_sac")) then   
    particleManager:addParticle(
        particles, false,
        0.1 * l, 0, 0.1,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3.5,                           
        Texture:of("minecraft","textures/a3dsp/b_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:prismarine_crystals")) then   
    particleManager:addParticle(
        particles, false,
        0 * l, 0, 0.1,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        2,                           
        Texture:of("minecraft","textures/a3dsp/w_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:glow_item_frame")) then   
    particleManager:addParticle(
        particles, false,
        0 * l, 0, 0,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3,                           
        Texture:of("minecraft","textures/a3dsp/w_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
	
if I:isOf(item, Items:get("minecraft:nether_star")) then   
    particleManager:addParticle(
        particles, false,
        0.1 * l, 0.2, 0,                 
        0, 0, 0,
        0, 0, 0, 0, 0, 0,
        3.5,                           
        Texture:of("minecraft","textures/a3dsp/w_glow.png"),
        "ITEM", hand, "SPAWN", "ADDITIVE", 0,
        225 + (20 * M:sin(P:getAge(player) * 0.2))  
    )
    
    end
