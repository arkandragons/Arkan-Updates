local l = (data.bl and 1) or -1
local player = data.player
local item = data.item
local mainHand = data.mainHand

global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

-- fishing пиздец

if I:isOf(item, Items:get("minecraft:fishing_rod")) then
    animator:rotateZ( 0, 22, M:clamp(P:getPitch(player) / 1, -25, 90) + ptAngle, 0.3, 1.9, 0.5, 0.4)
    animator:rotateX( 0, 22, M:clamp(P:getPitch(player) / 1, 0, 0) + ywAngle, 0.3, 1.9, 0.5, 0.4)
    animator:moveX(0, 22, -0.1)
end	

if I:isOf(item, Items:get("minecraft:warped_fungus_on_a_stick")) or I:isOf(item, Items:get("minecraft:carrot_on_a_stick")) then
    animator:rotateZ( 0, 47, M:clamp(P:getPitch(player) / 1, -25, 90) + ptAngle, 0.3, 1.9, 0.5, 0.4)
    animator:rotateX( 0, 47, M:clamp(P:getPitch(player) / 1, 0, 0) + ywAngle, 0.3, 1.9, 0.5, 0.4)
    animator:moveX(0, 32, -0.1)
end

-- Banner Pattern

if I:isOf(item, Items:get("minecraft:flower_banner_pattern")) or I:isOf(item, Items:get("minecraft:creeper_banner_pattern")) or I:isOf(item, Items:get("minecraft:skull_banner_pattern")) or I:isOf(item, Items:get("minecraft:mojang_banner_pattern"))or I:isOf(item, Items:get("minecraft:globe_banner_pattern")) or I:isOf(item, Items:get("minecraft:piglin_banner_pattern"))or I:isOf(item, Items:get("minecraft:flow_banner_pattern")) or I:isOf(item, Items:get("minecraft:guster_banner_pattern")) or I:isOf(item, Items:get("minecraft:field_masoned_banner_pattern")) or I:isOf(item, Items:get("minecraft:bordure_indented_banner_pattern")) or I:isOf(item, Items:get("minecraft:piglin_banner_pattern")) then
    animator:rotateX( 6, 7, M:clamp(P:getPitch(player) / 1, -40, 90) + ptAngle, 0.4, 0.5, 0.5, -0.5)
    animator:rotateZ( 6, 7, M:clamp(P:getPitch(player) / 1, 0, 0) - ywAngle, 0.4, 0.5, 0.5, -0.5)
    animator:moveY(6, 7, 0.03)
end

-- Other Stuff

if I:isOf(item, Items:get("minecraft:bamboo_chest_raft")) then
    animator:moveY(0, 62, 0.1)
end

if I:isOf(data.item, Items:get("minecraft:paper")) or I:isOf(data.item, Items:get("minecraft:map")) then
    animator:rotateX( 4, 7, M:clamp(P:getPitch(player) / 1, -25, 30) + ptAngle + ywAngle * 1, 0, 0.4, 0.505)
    animator:rotateX( 2, 5, M:clamp(P:getPitch(player) / 1, -20, 20) + ptAngle + ywAngle * 1, 0, 0.03, 0.28)
end

if I:isOf(data.item, Items:get("minecraft:name_tag")) then
    animator:rotateX( 0, 5, M:clamp(P:getPitch(player) / 1, -90, 90) + ptAngle + ywAngle * 1, 0, 0.2, 0.4)
    animator:rotateZ( 0, 5, -ywAngle, 0.5, 0.2, 0.4)
end

if I:isOf(data.item, Items:get("minecraft:writable_book")) then
    animator:rotateZ( 0, 1, M:clamp(P:getPitch(player) / 1, -45, -10) + ptAngle + ywAngle * 1, 0.5, 0.1, 1)
end

if I:isOf(data.item, Items:get("minecraft:armor_stand")) then
    animator:rotateZ( 0, 41, -ywAngle, 0.5, 0, 0)
end


if I:isOf(data.item, Items:get("minecraft:white_harness")) or
   I:isOf(data.item, Items:get("minecraft:light_gray_harness")) or
   I:isOf(data.item, Items:get("minecraft:gray_harness")) or
   I:isOf(data.item, Items:get("minecraft:black_harness")) or
   I:isOf(data.item, Items:get("minecraft:brown_harness")) or
   I:isOf(data.item, Items:get("minecraft:red_harness")) or
   I:isOf(data.item, Items:get("minecraft:orange_harness")) or
   I:isOf(data.item, Items:get("minecraft:yellow_harness")) or
   I:isOf(data.item, Items:get("minecraft:lime_harness")) or
   I:isOf(data.item, Items:get("minecraft:green_harness")) or
   I:isOf(data.item, Items:get("minecraft:cyan_harness")) or
   I:isOf(data.item, Items:get("minecraft:light_blue_harness")) or
   I:isOf(data.item, Items:get("minecraft:blue_harness")) or
   I:isOf(data.item, Items:get("minecraft:purple_harness")) or
   I:isOf(data.item, Items:get("minecraft:magenta_harness")) or
   I:isOf(data.item, Items:get("minecraft:pink_harness")) then
	animator:rotateZ( 0, 25, M:clamp(P:getPitch(player) / 1, 0, 40) + ptAngle, 0.8, 0.4, 2, 0.4)
	animator:rotateZ( 26, 51, M:clamp(P:getPitch(player) / -1, -40, 0) - ptAngle, 0.1, 0.4, 2, 0.4)
	animator:rotateX( 52, 66, M:clamp(P:getPitch(player) / 1, 0, 0) + ptAngle, 0.5, 0.4, 0.4, 0.4)
end



