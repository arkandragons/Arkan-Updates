global.GHP_disableShearing = 0.0;
global.GHP_disableShearingMPA = 0.0;

GHP_disableShearing = GHP_disableShearing + 1	-- disable shearing
GHP_disableShearingMPA = GHP_disableShearingMPA + 1	-- disable shears modelpart animation

local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent

local l = (bl and 1) or -1

function easeOutBack(t, back, speed)
    back = back or 1.70158
    speed = speed or 1.0
    t = math.min(math.max(t * speed, 0), 1)
    t = t - 1
    return (t * t * ((back + 1) * t + back) + 1)
end

function easeCustomSec(t)
	local t2 = t * t
	local t3 = t2 * t
	return 3 * t * (1 - t) * (1 - t) * 0.44 +
		3 * t2 * (1 - t) * 0.94 +
		t3
end


if I:isOf(item, Items:get("minecraft:name_tag")) or I:isOf(item, Items:get("minecraft:vine")) or I:isOf(item, Items:get("minecraft:glow_lichen")) or I:isOf(item, Items:get("minecraft:twisting_vines")) or I:isOf(item, Items:get("minecraft:weeping_vines")) or I:isOf(item, Items:get("minecraft:hanging_roots")) or I:isOf(item, Items:get("minecraft:pale_hanging_moss")) or I:isOf(item, Items:get("minecraft:globe_banner_pattern")) or I:isOf(item, Items:get("minecraft:field_masoned_banner_pattern")) or I:isOf(item, Items:get("minecraft:flow_banner_pattern")) or I:isOf(item, Items:get("minecraft:guster_banner_pattern")) or I:isOf(item, Items:get("minecraft:mojang_banner_pattern")) or I:isOf(item, Items:get("minecraft:skull_banner_pattern")) or I:isOf(item, Items:get("minecraft:piglin_banner_pattern")) or I:isOf(item, Items:get("minecraft:flower_banner_pattern")) or I:isOf(item, Items:get("minecraft:creeper_banner_pattern")) or I:isOf(item, Items:get("minecraft:bordure_indented_banner_pattern")) or I:isOf(item, Items:get("minecraft:glow_item_frame")) then
    M:moveY(matrices, 0.25)
    M:moveZ(matrices, -0.05)
end

